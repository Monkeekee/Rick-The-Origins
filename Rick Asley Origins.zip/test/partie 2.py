print("@echo off")
print("pause > nul")

def final(tab):
    for k in range(1, len(tab[0])+1):
        print("echo {}".format(tab[0][:k]))
        print("echo {}".format(tab[1][:k]))
        print("echo {}".format(tab[2][:k]))
        print("echo {}".format(tab[3][:k]))
        print("echo {}".format(tab[4][:k]))
        print("echo {}".format(tab[5][:k]))
        print("pathping 127.0.0.1 -n -q 1 -p 1 >nul")
        print("cls")


final(["Why so much hate my love (^.^)/ ?                ",
"Y aurait t'il un moyen de sauver notre ...(u-u)",
"Avec toi je suis dans un ascenseur, en a... (u_u)",
"Yves notre ami en est témoin, j'a... ('･_･')",
"Il y a deux types de personnes d... {•̃_•̃}",
"Gare à toi, Rendez-Vous sur le terrain de ba... "])

def final_reverse(tab):
    for k in reversed(range(len(tab[0])+1)):
        print("echo {}".format(tab[0][0:k]))
        print("echo {}".format(tab[1][0:k]))
        print("echo {}".format(tab[2][0:k]))
        print("echo {}".format(tab[3][0:k]))
        print("echo {}".format(tab[4][0:k]))
        print("echo {}".format(tab[5][0:k]))
        print("pathping 127.0.0.1 -n -q 1 -p 1 >nul")
        print("cls")

final_reverse(["Why so much hate my love (^.^)/ ?                ",
"Y aurait t'il un moyen de sauver notre ...(u-u)",
"Avec toi je suis dans un ascenseur, en a... (u_u)",
"Yves notre ami en est témoin, j'a... ('･_･')",
"Il y a deux types de personnes d... {•̃_•̃}",
"Gare à toi, Rendez-Vous sur le terrain de ba... "])

final(["We're no strangers to love",
"You know the rules and so do I",
"A full commitment's what I'm thinking of",
"You wouldn't get this from any other guy",
"I just wanna tell you how I'm feeling",
"Gotta make you understand"])

print("pause > nul")

real(["Never gonna give you up",
"Never gonna let you down",
"Never gonna run around and desert you",
"Never gonna make you cry",
"Never gonna say goodbye",
"Never gonna tell a lie and hurt you"])

print("pause > nul")
