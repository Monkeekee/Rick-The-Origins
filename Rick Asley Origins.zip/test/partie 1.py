def real(tab):
    for j in range(0,len(tab)):
        for k in range(1,len(tab[j])+1, 2):
            for i in range(j):
                print("echo {}".format(tab[i]))
            print("echo {}".format(tab[j][:k+1]))
            print("pathping 127.0.0.1 -n -q 1 -p 1 >nul")
            print("cls")


def question(n, text):
    print("set /p reponse=")
    print("if %reponse% neq {} goto perdu{}".format(n, text))
    print("cls")

print(":debut")
print("@echo off")

real(["Prologue:",
"10 jours que je ne vois Mélanie uniquement dans mes songes, ça petite bouille blonde me manque terriblement.",
"Alors que j'avais perdu tout espoir, une lueur apparut :",
"Mélanie:",
"Tu sais, je ne pense pas que je pourrais te le pardonner un jour...",
"1: Je n'ai pas besoin de ton pardon, seul le seigneur peut me juger!",
"2: Why so much hate my love (^.^)/ ?"])

question(2, "Ok")

real(["Melanie:",
"Ne me sous estime pas, je suis devenue plus forte, ton anglicisme ne te sauvera pas cette fois  ci.",
"Un chevalier d'or ne tombe pas deux fois face a la même attaque !",
"1: Y aurait t'il un moyen de sauver notre relation ? (u-u)",
"2: C'est sans compter sur la puissance de mon épée!"])

question(1, "Va")

real(["Melanie",
"Oh toi ! Cela fait 10 jours que tu ne me parles pas et tu reviens comme une fleur, je ne t'en ferai pas une cette fois ci.",
"1: Je ne veux pas de ta fleur, je ne suis pas une abeille je n'ai point besoin de butiner.",
"2: Avec toi je suis dans un ascenseur, en apesanteur jusqu'au paradis mais quand tu t'éloignes",
"je me sens comme une baguette de campagne, sec et l'âme pleines de trous. (u_u)"])

question(2, "Adieu")

real(["Melanie:",
"Je ne comprend toujours pas ton geste Rick",
"je n'ai jamais eu aussi honte que l'autre jour peut-être la dernière fois que l'on s'est vu, qui sait ?",
"1: Tu connais l'importance du basket pour moi Mélanie,  j'étais obligé de me donner à 100% et de te dunker dessus,",
"je sais que c'est difficile à accepter mais c'est une preuve d'amour de ma part (♨_♨).",
"2: Yves notre ami en est témoin, j'ai simplement performé mon meilleur basket à mon habitude.",
"Tu sais tu pourrais entrainer ta détente et te venger d'un dunk assassin la prochaine fois ! ('･_･')"])

question(2, "Tu")

real(["Mélanie :",
"Tu m'as battu cette fois-ci car je ne m'attendais pas à de telle bassesse de ta part",
"mais je t'attendrai de pied ferme avec une technique flamboyante!",
"1: Les faibles ne cherchent que des excuses et ne trouvent que la défaite !",
"2: Il y a deux types de personnes dans la vie , les dunkers et les dunkés … {•̃_•̃}"])

question(2, "Celui")
real(["Melanie:",
"Il suffit ! On se retrouve demain pour laisser le ballon rond décider de notre destin !",
"1: Lol non ^^",
"2: Gare à toi, Rendez-Vous sur le terrain de basket !",
"On se ferait pas un petit ciné juste après pendant la soirée en toute sympathie ? (^.^)/"])

question(1, "Je")

real(["Why so much hate my love (^.^)/ ?",
"Y aurait t'il un moyen de sauver notre relation ? (u-u)",
"Avec toi je suis dans un ascenseur, en apesanteur jusqu'au paradis mais quand tu t'éloignes,",
"je me sens comme une baguette de campagne, sec et l'âme pleines de trous. (u_u)",
"Yves notre ami en est témoin, j'ai simplement performé mon meilleur basket à mon habitude.",
"Tu sais tu pourrais entrainer ta détente et te venger d'un dunk assassin la prochaine fois ! ('･_･')",
"Il y a deux types de personnes dans la vie , les dunkers et les dunkés … {•̃_•̃}",
"Gare à toi, Rendez-Vous sur le terrain de basket !",
"On se ferait pas un petit ciné juste après pendant la soirée en toute sympathie ? (^.^)/"])